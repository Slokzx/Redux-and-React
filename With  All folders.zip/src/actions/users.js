import axios from 'axios';
/////////////////////////////////////////////// Async Actions /////////////////////////////////////

// this is the main action. There are 3 sub actions
// one is to get the user which is dispatched everytime the store is called.
// the api call is taken from the randomuser webpage where there are multiple opensource apis
// second is the USER_RECIEVED which is called if the user request is completed successfully
// the payload is what will be received when the action is called. in this case its the api call results.
// third is the error which is called everytime there is an error will the api call
// the error payload will be receiving the error. This will be the same error came from the console
// getuser is the button id which when clicked will take the details

// document.getElementById('getUser')
//   .addEventListener('click', function () {
    // store.dispatch(dispatch => {
    //   // ASYNC ACTION
    //   // dispatch action
    //   dispatch({type: 'GET_USER'});
    //   // do the xhr request
    //   axios.get('https://randomuser.me/api/')
    //   // handle response
    //   // success
    //     .then(response => {
    //       dispatch({type: 'USER_RECIEVED', payload: response.data.results})
    //     })
    //   // error
    //   .catch(error => {
    //     dispatch({ type: 'ERROR', payload: error})
    //   })
    //   dispatch({type: 'AFTER ASYNC ACTION'});
    // });
    //    store.dispatch({
    //    type: 'FETCH_USER',
    //    payload: axios.get("https://randomuser.me/api/")
    // });
    // async action using promise
    //});
export default function fetchUsers(){
    return {
    type: 'FETCH_USER',
    payload: axios.get("https://randomuser.me/api/?results=10")
    }
 };
