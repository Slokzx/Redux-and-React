import React from 'react';

class Users extends React.Component {
  constructor(props) {
    super(props);
    // therefore we have mapped the state to the props
    this.componentDidMount = this.componentDidMount.bind(this);
  }
  // to check the current props
  componentDidMount() {
    console.log(this.props);
    this.props.fetchUsers();
  }
  render() {
    return (
      <div>
        hello
      </div>
    )
  }
}

export default Users;
