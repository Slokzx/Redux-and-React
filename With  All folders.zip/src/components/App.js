import React from 'react';
class App extends React.Component {
  constructor(props) {
    super(props); // We have to mention super which takes props before using the 'this' keyword.
    this.state = {  // intial states of the state components.
      num1: "",
      num2: "",
      Result: 0
    }
    // we have to bind each of the functions used in the react app. This is not done automatically by the react app.
    this.addi = this.addi.bind(this);
    this.subt = this.subt.bind(this);
    this.mul = this.mul.bind(this);
    this.divi = this.divi.bind(this);
    this.resetting = this.resetting.bind(this);
    this.handleNameChange1 = this.handleNameChange1.bind(this);
    this.handleNameChange2 = this.handleNameChange2.bind(this);
  }

  //addition It takes the two states value. Stores it into a local variable and add it into another.
  // The the result will be stores in the state value of Result.
  addi() {
    let num1 = parseInt(this.state.num1);
    let num2 = parseInt(this.state.num2);
    let Results = num1 + num2;
    this.setState({Result: Results});
  }
  // subtraction
  subt() {
    let num1 = parseInt(this.state.num1);
    let num2 = parseInt(this.state.num2);
    let Results = num1 - num2;
    this.setState({Result: Results});
  }
  // multiplication
  mul() {
    let num1 = parseInt(this.state.num1);
    let num2 = parseInt(this.state.num2);
    let Results = num1 * num2;
    this.setState({Result: Results});
  }
  //division
  divi() {
    let num1 = parseInt(this.state.num1);
    let num2 = parseInt(this.state.num2);
    let Results = num1 / num2;
    this.setState({Result: Results});
  }
  //resetting the values. The original states are set as the initial values
  resetting() {
    this.setState({Result: 0, num1: "", num2: ""});
  }
  // This will store the changed value of the first input field into the state of num1
  handleNameChange1(event) {
    const event1 = event.target.value;
    this.setState({num1: event1});
  }
  // This will store the changed value of the second input field into the state of num2
  handleNameChange2(event) {
    const event2 = event.target.value;
    this.setState({num2: event2});
  }

  render() {
    //This is the main container
    return (<div className="main">
      <div className="left">
        <p>Enter First Number =
        </p>
        <p><input type='text' onChange={this.handleNameChange1} value={this.state.num1}/>
        </p>
        <p>Enter Second Number =
        </p>
        <p><input type='text' onChange={this.handleNameChange2} value={this.state.num2}/>
        </p>
        <div>
          Result:
        </div>
        <div className="resulto">
          {this.state.Result}
        </div>
      </div>
      <div className="right">
        <ul>
          <li>
            <button className="buttongreen" onClick={this.addi}>Add</button>
          </li>
          <li>
            <button className="buttongreen" onClick={this.subt}>Subtract</button>
          </li>
          <li>
            <button className="buttongreen" onClick={this.mul}>Multiply</button>
          </li>
          <li>
            <button className="buttongreen" onClick={this.divi}>Divide</button>
          </li>
          <li>
            <button className="buttonred" onClick={this.resetting}>Reset</button>
          </li>
        </ul>
      </div>
    </div>);
  }
}
export default App;
