import React from 'react';
class First extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      todo: [],
      title: 'React Simple CRUD Application'
    }
    this.addTodo=this.addTodo.bind(this);
  }
  addTodo(event){
  event.preventDefault();
  let name = this.refs.name.value;
  let completed = this.refs.name.value;
  let todo ={

  }
  }
   render() {
      let title =this.state.title;
      return (
         <div className="FirstContainer">
           <h1>{title}</h1>
            <form>
              <input type="text" ref="name" />
              <input type="text" ref="completed" />
              <button onClick={this.addTodo}>Add Todo </button>
            </form>
         </div>
      );
   }
}
export default First;
