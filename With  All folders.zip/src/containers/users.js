import { connect } from 'react-redux';
import Users from '../components/users';
import fetchUsers from '../actions/users';
// it maps the state to the props
// data is just an example
const mapStateToProps = (state) => ({
  data: state,
})
 // mapStateToProps function is passed to connect.
 // What coonect will do is it will call the function
 // Then the react component should get the state and the value.
 // component is called by the container which isthen called by the main app
const mapDispatchToProps = (dispatch) => {
  return{
    fetchUsers: () => {
      dispatch(fetchUsers())
    }
  }
}
// this will map a property called fetchUsers into the react component
// then we can call which will disptach the action in fetchUsers
const UsersContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(Users)

export default UsersContainer;
