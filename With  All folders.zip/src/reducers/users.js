
const initalState = {
  users: [],
  loading: false,
  error: null,
};
function usersReducer(state=initalState, action) {
  let users; // since we will have multiple users
  switch (action.type) {
    // this is the action where the api will get the users
    // the status pending will be displayed in the console.
  //  case 'GET_USER':
    case 'FETCH_USER_PENDING':
      return {...state, loading: true}
      break;
  //  case 'USER_RECIEVED':
    case 'FETCH_USER_FULFILLED':
    // `` is the syntax for string interpretation in es6. it will take from the payload taking the first element
    // since we are taking only one user. same as email and gender.
    // for thunk it is payload[0]. press alt-f3 to select all
      users = action.payload.data.results; // since we will get multiple users
      return {...state, loading: false, users}
    break;
  //  case 'ERROR':
    case 'FETCH_USER_REJECTED':
    // the error will be the same one from the console
    return {...state, loading: false, error: `${action.payload.message}`}
    default:
      return state
  }
}

export default usersReducer;
