import { createStore, combineReducers, applyMiddleware } from 'redux';
// this is the external middleware installed by npm install --save redux-logger
import logger from 'redux-logger';
import thunkMiddleware from 'redux-thunk';
import promise from 'redux-promise-middleware'
import usersReducer from './reducers/users'
import React from 'react';
import ReactDOM from 'react-dom';

export default createStore(
  usersReducer,
  applyMiddleware(
    logger,
    promise()
  )
);
// // for using with thunk middleware
// //store
// /////////////////////////////////////////////////////AsyncReducer///////////////////////////////////
// // it takes the initalState which is the blank user profile
// // this is the intial state of the user and the status
// // sendingRequest false means there is no api call
// // requestRecieved false will mean that the api call is not received or not being requesting.
// // this is the intial state of all the api calls.
// const initalState = {
//   sendingRequest: false,
//   requestRecieved: false,
//   user: {
//     name: '',
//     email: '',
//     gender: ''
//   },
//   status: '',
//   statusClass: ''
// }
// const store = createStore(userReducer, applyMiddleware(logger, promise()));
// //const store = createStore(userReducer, applyMiddleware(logger, thunkMiddleware));
// /////////////////////////////////////////async store ///////////////////////////////////////////////
// const nameEl = document.getElementById('name');
// const emailEl = document.getElementById('email');
// const genderEl = document.getElementById('gender');
// const statusEl = document.getElementById('status');
//
// function render(){
//   const state = store.getState();
//   nameEl.innerHTML = state.user.name;
//   emailEl.innerHTML = state.user.email;
//   genderEl.innerHTML = state.user.gender;
//   statusEl.innerHTML = state.status;
//   statusEl.className = state.statusClass;
// }
