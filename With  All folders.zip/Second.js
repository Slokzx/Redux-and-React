import React from 'react';
class Second extends React.Component {
   render() {
      return (
         <div>
            Hello World ReactJS!!!
         </div>
      );
   }
   
}
export default Second;
